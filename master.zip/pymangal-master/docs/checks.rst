.. _check:

Checks of user-supplied arguments
=================================

Several methods share arguments, so it made sense to have a set of functions
designed to validate the in the same place. These functions are all in
``pymangal.checks``, and are used internally only by the different methods.

Documentation
-------------

.. module:: pymangal.checks

.. autofunction:: check_resource_arg

.. autofunction:: check_upload_res

.. autofunction:: check_filters
