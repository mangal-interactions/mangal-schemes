.. _api:

The mangal class
================

The ``mangal`` class is where most of the action happens. Almost all user
actions consist in calling various methods of this class.

Documentation
-------------

.. module:: pymangal

.. autoclass:: mangal
   :members:
