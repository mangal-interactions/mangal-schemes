# 0.3.0

- `Patch` function
- Better tests using a real database
